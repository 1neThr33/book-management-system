import React from 'react'

function Delete() {
  return (
    <div>Delete</div>
  )
}

export default Delete