package com.example.bookmanagementback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagementBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
